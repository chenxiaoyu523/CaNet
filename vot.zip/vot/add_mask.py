import os
import cv2
import matplotlib.pyplot as plt
import numpy as np

f = open('basketball/groundtruth.txt')

iter = 1
while True:
    text_line = f.readline()
    if text_line:
        x0, y0, x1, y1, x2, y2, x3, y3 = [int(float(ele)) for ele in text_line.split(',')]

        area = np.array([[x0, y0], [x1, y1], [x2, y2], [x3, y3]])

        img = cv2.imread('basketball/%08d.jpg'%iter)
        mask = np.zeros_like(img[...,0])

        cv2.fillPoly(mask, [area], 255)
        #cv2.line(img,(x0,y0),(x1,y1),(0,255,0),3)
        #cv2.line(img,(x2,y2),(x3,y3),(0,255,0),3)

        #cv2.imshow('im', img)
        #cv2.imshow('mask', mask)
        #cv2.waitKey()

        cv2.imwrite('basketball_m/%08d.jpg'%iter, mask)

        iter = iter + 1
    else:
        break
